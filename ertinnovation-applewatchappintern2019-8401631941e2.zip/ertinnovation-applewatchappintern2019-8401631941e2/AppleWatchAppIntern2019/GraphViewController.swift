//
//  GraphViewController.swift
//  AppleWatchAppIntern2019
//
//  Created by Carolyn DeJesus Martinez on 8/6/19.
//  Copyright © 2019 Carolyn DeJesus Martinez. All rights reserved.
//

import UIKit
import Foundation
import Charts
import HealthKit

class GraphViewController: UIViewController {
    
    @IBOutlet weak var pieChart: PieChartView!
    
    var heartRateValue = ""
    var stepCountValue = ""
    var flightsClimbedValue = ""
    var distanceWalkingValue = ""
    
    var heartRate = PieChartDataEntry()
    var stepCount = PieChartDataEntry()
    var flightsClimbed = PieChartDataEntry()
    var distanceWalking = PieChartDataEntry()

    var numberOfDownloadsDataEntries = [PieChartDataEntry]()

    override func viewDidLoad() {
        super.viewDidLoad()
       
        heartRate = PieChartDataEntry(value: Double(heartRateValue) ?? 0 )
        stepCount = PieChartDataEntry(value:  Double(stepCountValue) ?? 0 )
        flightsClimbed = PieChartDataEntry(value:  Double(flightsClimbedValue) ?? 0)
        distanceWalking = PieChartDataEntry(value:  Double(distanceWalkingValue) ?? 0)
        
        self.pieChart.backgroundColor = UIColor.white
       
        pieChart.chartDescription?.text = ""
        
        heartRate.label = "Heart Rate"
        stepCount.label = "Steps Count"
        flightsClimbed.label = "Flights Climbed"
        distanceWalking.label = "Distance Walking"
        
        numberOfDownloadsDataEntries = [heartRate, stepCount, flightsClimbed, distanceWalking]

        updateChartData()
        
    }
 
    func updateChartData() {
        
        let chartDataSet = PieChartDataSet(entries: numberOfDownloadsDataEntries, label: nil)
        let chartData = PieChartData(dataSet: chartDataSet)
        let colors = [UIColor.magenta, UIColor.orange, UIColor.blue, UIColor.purple]
        chartDataSet.colors = colors
        
        pieChart.data = chartData
        pieChart.legend.orientation = Legend.Orientation.vertical
        pieChart.legend.font = UIFont(name: "TimesNewRomanPSMT", size: 20)!
        
        pieChart.legend.xEntrySpace = 10
        pieChart.legend.yEntrySpace = -50

    }
    
    @IBAction func backButton(_ sender: UIButton) {
    self.performSegue(withIdentifier: "mySegue4", sender: self)
    }

}
    
    
    
    
 

