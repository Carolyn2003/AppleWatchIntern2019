//
//  TableViewController.swift
//  AppleWatchAppIntern2019
//
//  Created by Carolyn DeJesus Martinez on 7/24/19.
//  Copyright © 2019 Carolyn DeJesus Martinez. All rights reserved.
//

import UIKit
import HealthKit


class StackViewController: UIViewController {

    //Mark: Properties
    
    //Heart Rate Labels
    @IBOutlet weak var heartRateDateLabel: UILabel!
    @IBOutlet weak var heartRateLabel: UILabel!
    
    // Step Count Labels
    @IBOutlet weak var stepCountDateLabel: UILabel!
    @IBOutlet weak var stepCountLabel: UILabel!
    
    // Walking Distance Labels
    @IBOutlet weak var walkingDistanceDateLabel: UILabel!
    @IBOutlet weak var walkingDistanceLabel: UILabel!
    
    // Flights Climbed
    @IBOutlet weak var flightsClimbedDateLabel: UILabel!
    @IBOutlet weak var flightsClimbedLabel: UILabel!
    
    // Upload Display Label
    @IBOutlet weak var uploadButton: UIButton!
    
    @IBOutlet weak var uploadSuccessfullyLabel: UILabel!
    @IBOutlet weak var txtDatePicker: UITextField!
    let datePicker = UIDatePicker()
   // let dateLabel : UILabel!
    
    
    @IBOutlet weak var BPM: UILabel!
    @IBOutlet weak var steps: UILabel!
    @IBOutlet weak var meters: UILabel!
    @IBOutlet weak var flights: UILabel!
    
    let BASE_URL = "https://64gaowlaw8.execute-api.us-east-1.amazonaws.com/v1/api/"
    let healthStore = HKHealthStore()
    var stepSum = 0
    var distanceSum = 0
    var avgHeartRate = 0
    var flightsClimbedTotal = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        avgHeartRatefunc()
        totalStepCount()
        distanceTotal()
        flightsTotal()
        uploadSuccessfullyLabel.isHidden = true
        showDatePicker()
       
    }
    func dateFormatget(date : Date) -> String {
        let dateFormatterget = DateFormatter()
        dateFormatterget.dateFormat = "MM/dd/yyyy"
        return dateFormatterget.string(from: date)
    }
    
    func showDatePicker(){
        txtDatePicker.text = dateFormatget(date : Date())
        //Formate Date
        datePicker.datePickerMode = .date
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        
        txtDatePicker.inputAccessoryView = toolbar
        txtDatePicker.inputView = datePicker
        
    }
    
    @objc func donedatePicker(){
        txtDatePicker.text = dateFormatget(date : datePicker.date)
        self.view.endEditing(true)
        let actualDate = dateFormatget(date : Date())
        if !(txtDatePicker.text == actualDate){
            uploadButton.isHidden = true
            uploadSuccessfullyLabel.isHidden = true
            getHealthData (dateLabel: heartRateDateLabel , resultLabel: heartRateLabel, sampleName: "heart_rate", units: 0)
            getHealthData (dateLabel: flightsClimbedDateLabel , resultLabel: flightsClimbedLabel, sampleName: "flights_climbed", units: 1)
            getHealthData (dateLabel: stepCountDateLabel , resultLabel: stepCountLabel, sampleName: "steps_count", units: 2)
            getHealthData (dateLabel: walkingDistanceDateLabel , resultLabel: walkingDistanceLabel, sampleName: "distance_walking", units:3)
            
           
        }
        else{
            uploadButton.isHidden = false
            avgHeartRatefunc()
            totalStepCount()
            distanceTotal()
            flightsTotal()
        }
       
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
    
    func avgHeartRatefunc (){

        guard let sampleHeartRate = HKObjectType.quantityType(forIdentifier: .heartRate) else {
            return
        }
        let bpmUnit = HKUnit.count().unitDivided(by: HKUnit.minute())
        queryHealthData(dataType: sampleHeartRate, dateLabel: self.heartRateDateLabel, resultLabel: self.heartRateLabel, unit: bpmUnit) { sum in
                self.avgHeartRate = sum
                self.heartRateLabel.text = "\(sum)"
            }
    }

    func totalStepCount () {

        guard let sampleStep = HKSampleType.quantityType(forIdentifier: .stepCount) else {
            return
        }
        let stepUnit = HKUnit.count()
        queryHealthData(dataType: sampleStep, dateLabel: self.stepCountDateLabel, resultLabel: stepCountLabel, unit: stepUnit) { sum in
            self.stepSum = sum
            self.stepCountLabel.text = "\(sum)"
        }
    }

     func distanceTotal() {
        guard let sampleDistance = HKSampleType.quantityType(forIdentifier: .distanceWalkingRunning) else {
            return
        }
        let distanceUnit = HKUnit.meter()
        queryHealthData(dataType: sampleDistance, dateLabel: walkingDistanceDateLabel, resultLabel: walkingDistanceLabel, unit: distanceUnit) { sum in
             self.distanceSum = sum
             self.walkingDistanceLabel.text = "\(sum)"
        }
      }

    func flightsTotal() {

        guard let sampleFlights = HKSampleType.quantityType(forIdentifier: .flightsClimbed) else {
           return
      }
        let flightUnit = HKUnit.count()
        queryHealthData(dataType: sampleFlights, dateLabel: flightsClimbedDateLabel, resultLabel: flightsClimbedLabel, unit: flightUnit) { sum in
            self.flightsClimbedTotal = sum
            self.flightsClimbedLabel.text = "\(sum)"

        }
    }
 
    func startOfDay() -> Date {
        let startOfDay: Date = Calendar.current.startOfDay(for: Date())
        return startOfDay
    }
    func queryHealthData(dataType: HKSampleType, dateLabel: UILabel, resultLabel: UILabel, unit: HKUnit, completion: @escaping (Int) -> Void){

        let predicate = HKQuery.predicateForSamples(withStart: startOfDay(),end: Date(),options: .strictEndDate)
        let query = HKSampleQuery(sampleType: dataType, predicate: predicate, limit: Int(HKObjectQueryNoLimit), sortDescriptors: nil) {
            (query, results, error) in

            guard let data: [HKSample] = results else{
                fatalError("failed to query data from healthkit")
            }

            DispatchQueue.main.async {
                dateLabel.text = self.dateFormatget(date : Date())
                var sum = 0
                for element in data {
                    guard let typeElement = element as? HKQuantitySample else {
                        return
                    }

                    if typeElement.device?.name == "Apple Watch"{
                        sum += Int(typeElement.quantity.doubleValue(for: unit))
                    }
                }
                if resultLabel == self.heartRateLabel {
                    if data.count == 0 {
                        sum = 0;
                    }
                    else {
                        sum = sum/data.count
                    }
                }
                completion(sum)
            }
        }
        healthStore.execute(query)
    }
    var statusCode = 0
    func postHealthData(url : String , body: [ String:Any]){

        let session = URLSession.shared
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let params: [String: Any] = body
        print(params)
        do{
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
            let task = session.dataTask(with: request as URLRequest as URLRequest, completionHandler: {(data, response, error) in

                DispatchQueue.main.async {
                    if let response = response {
                        let nsHTTPResponse = response as! HTTPURLResponse
                        self.statusCode = nsHTTPResponse.statusCode
                        print ("status code = \(self.statusCode)")

                        if self.statusCode == 200{
                            self.uploadSuccessfullyLabel.isHidden = false
                            self.uploadSuccessfullyLabel.text = "All data was uploaded successfully"
                        }
                        else{
                            self.uploadSuccessfullyLabel.isHidden = false
                            self.uploadSuccessfullyLabel.text = "Data wasn't uploaded"
                        }

                    }
                    if let error = error {
                        print ("\(error)")
                    }
                    if let data = data {
                        do{
                            let jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions())
                            print ("data = \(jsonResponse)")
                        }catch  {
                            print ("OOps not good JSON formatted response " + error.localizedDescription)
                        }
                    }
                }
            })
            task.resume()
        }catch _ {
            print ("Oops something happened buddy")
        }
    }
    
    @IBAction func uploadButton(_ sender: UIButton) {
        let formatter2 = DateFormatter()
        formatter2.dateFormat = "hh:mm:ss a"
        let dateString = formatter2.string(from: Date())

        let name = UserDefaults.standard.string(forKey: "user_id") ?? ""

        //Uploading Heart Rate
        postHealthData(url: self.BASE_URL + "heart_rate", body: [ "user_id" : name ,"quantity" : avgHeartRate ,"date" : heartRateDateLabel.text!, "submitted_time": dateString ])
        //Uploading Steps Count
        postHealthData(url: self.BASE_URL + "steps_count", body: [ "user_id" : name ,"quantity" : stepSum  ,"date" : stepCountDateLabel.text!, "submitted_time": dateString ])
        //Uploading Flights Climbed
        postHealthData(url: self.BASE_URL + "flights_climbed", body: [ "user_id" : name ,"quantity" : flightsClimbedTotal  ,"date" : flightsClimbedDateLabel.text!, "submitted_time": dateString ])
        //Uploading Walking Distance
        postHealthData(url: self.BASE_URL + "distance_walking", body:["user_id" : name ,"quantity" : distanceSum  ,"date" : walkingDistanceDateLabel.text!, "submitted_time": dateString ])
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let vc = segue.destination as? GraphViewController
        
        guard let hr = self.heartRateLabel.text,
              let sc = self.stepCountLabel.text,
              let fc = self.flightsClimbedLabel.text,
              let dw = self.walkingDistanceLabel.text else { return }
                
        vc?.heartRateValue = hr
        vc?.stepCountValue = sc
        vc?.flightsClimbedValue = fc
        vc?.distanceWalkingValue = dw
    }

    
    @IBAction func graphButton(_ sender: UIButton) {
        self.performSegue(withIdentifier: "mySegue3", sender: self)
        
    }
    @IBAction func logOutButton(_ sender: UIButton) {
        self.performSegue(withIdentifier: "mySegue2", sender: self)
    }

    func getHealthData (dateLabel : UILabel , resultLabel : UILabel, sampleName: String , units: Int){
        
        guard let pickedDate = txtDatePicker.text else{
            print ("txtDatePicker is not unwrapped")
            return
        }
        let url =  "\(BASE_URL)\(sampleName)/ert/"+"?date=\(pickedDate)"
        // Create NSURL Ibject
        let session = URLSession.shared
    
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
       
        do{
            let task = session.dataTask(with: request as URLRequest as URLRequest, completionHandler: {(data, response, error) in

                DispatchQueue.main.async {
                    if let response = response {
                        let nsHTTPResponse = response as! HTTPURLResponse
                        let statusCode = nsHTTPResponse.statusCode
                        print ("status code = \(statusCode)")
                        dateLabel.text = pickedDate
                        
                    }
                    if let error = error {
                        print ("\(error)")
                    }
                    if let data = data {
                        do{
                            var jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions()) as? [[String:Any]]
                           //print ("data = \(jsonResponse)")
                            if let json = jsonResponse {
                                if json.count > 0{
                                    if let quantity = jsonResponse?[0]["quantity"] {
                                            resultLabel.text = "\(quantity)"
                                        self.meters.isHidden = false
                                        self.BPM.isHidden = false
                                        self.flights.isHidden = false
                                        self.steps.isHidden = false
                                    }
                                }
                                else {
                                    self.meters.isHidden = true
                                    self.BPM.isHidden = true
                                    self.flights.isHidden = true
                                    self.steps.isHidden = true
                                    resultLabel.text = "No Data"
                                }
                            }
                        
                            
                           // print(jsonResponse.arrayObject)
                        }catch _ {
                            print ("OOps not good JSON formatted response")
                        }
                    }
                }
            })
            task.resume()
        }
    }
}

    
    


