//
//  ViewController.swift
//  AppleWatchAppIntern2019
//
//  Created by Carolyn DeJesus Martinez on 7/24/19.
//  Copyright © 2019 Carolyn DeJesus Martinez. All rights reserved.
//

import UIKit
import Foundation
import Charts

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var usernameInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        usernameInput.delegate  = self
        passwordInput.delegate = self
        errorLabel.isHidden = true
        passwordInput.isSecureTextEntry = true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }

    
    //Actions

    @IBAction func signInButton(_ sender: UIButton) {
       
        UserDefaults.standard.set( self.usernameInput.text!, forKey: "user_id")

  
        let session = URLSession.shared
        let url = "https://64gaowlaw8.execute-api.us-east-1.amazonaws.com/v1/api/user/authentication"
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let params: [String: String] = ["user_id" : usernameInput.text!, "password" : passwordInput.text!]
        print(params)
        do{
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
            let task = session.dataTask(with: request as URLRequest as URLRequest, completionHandler: {(data, response, error) in
                
                DispatchQueue.main.async {
                    if let response = response {
                        let nsHTTPResponse = response as! HTTPURLResponse
                        let statusCode = nsHTTPResponse.statusCode
                        print ("status code = \(statusCode)")
                        if (statusCode == 200){
                            self.reDirectToStackView()
                        }
                        else {
                            self.errorLabel.isHidden = false
                            self.errorLabel.text = "You have entered a wrong username or password, please try again."
                            
                        }
                    }
                    if let error = error {
                        print ("\(error)")
                    }
                    if let data = data {
                        do{
                            let jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions())
                            print ("data = \(jsonResponse)")
                        }catch _ {
                            print ("OOps not good JSON formatted response")
                        }
                    }
                }
            })
            task.resume()
        }catch _ {
            print ("Oops something happened buddy")
        }
    }
    
    func reDirectToStackView() {
        self.performSegue(withIdentifier: "mySegue", sender: self)
    }
    
}

        

